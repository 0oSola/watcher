(function(){
	var app = angular.module('watcher',['loading','clock','chartComponent']);
})();